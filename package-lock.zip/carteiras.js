[
    {
        "id": "3a9712c0-6dcd-42eb-a81c-a21576da78fc",
        "publicKey": "0x38A8D21C2288995B490BFCE189E9AC0236071DF1",
        "privateKey": "92de1765df181bba5576558f4af5625b18340b07ed7220b5afee725f73e2c157",
        "balance": 100
    },
    {
        "id": "5e431634-9060-4887-b268-146661c01b2b",
        "publicKey": "0xA0AEA4E104E109597F7C963BA8D5323F610CD81E",
        "privateKey": "87e23605e4c22bd1a2dab866e5f0c8dd642d2b847dd2d2bf71f06ac62c8ca917",
        "balance": 100
    }
]

{
    "fromAddress": "0x38A8D21C2288995B490BFCE189E9AC0236071DF1",
    "toAddress": "0xA0AEA4E104E109597F7C963BA8D5323F610CD81E",
    "amount": 30,
    "tokenType": "PIN"
  }
  
  