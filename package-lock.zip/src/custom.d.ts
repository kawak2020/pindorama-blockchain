declare module 'solc';
